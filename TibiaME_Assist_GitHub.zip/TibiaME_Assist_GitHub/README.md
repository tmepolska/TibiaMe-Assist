# TibiaME Assist

**Android overlay prototype for tracking XP and damage per minute in TibiaME.**

> **Status: experimental / not validated for live gameplay.** This repository contains source code, not a ready-to-install APK. OCR can miss values, read unrelated UI text, or count the same event more than once. Do not treat its counters as authoritative game statistics.

## Planned features

- Small, movable floating panel above the game.
- XP gained during the current measurement session.
- Rolling damage total for the last 60 seconds (damage per minute, DPM).
- User-approved screen capture through Android MediaProjection.
- On-device text recognition using Google ML Kit.
- Pause and reset controls.

## Current implementation

- Native Android app written in Kotlin.
- Android application ID: `pl.tibiame.assist`.
- `minSdk`: 26 (Android 8.0).
- `compileSdk` / `targetSdk`: 35.
- Google ML Kit Text Recognition.
- Floating overlay permission and explicit screen-capture consent are required.

The implementation is an early prototype. It has **not yet been built and verified on a physical device**. In particular, OCR accuracy, duplicate suppression, Android background behavior, and performance during live gameplay still need testing.

## Open in Android Studio

1. Download or clone this repository.
2. Open the project root — the folder containing `settings.gradle.kts` — in Android Studio.
3. Install Android SDK Platform 35 if prompted.
4. Allow Gradle to sync and download the Android Gradle Plugin, Kotlin plugin, AndroidX Core, and ML Kit dependencies.
5. Use **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
6. If the build succeeds, Android Studio will show the generated debug APK location.

This repository currently does not include the Gradle Wrapper. If Android Studio cannot sync the project without it, generate/add the wrapper from a compatible Gradle installation before building. No APK is included in this repository.

## First-run flow

1. Install and open the debug APK.
2. Tap **Uruchom nakładkę i odczyt**.
3. Grant permission to display over other apps.
4. Return to the app and tap start again if needed.
5. Approve Android's screen-capture prompt.
6. Switch to TibiaME and move the overlay by dragging its header.
7. Stop the service from the app when finished.

Android displays a persistent foreground-service notification while capture is active. Screen capture only starts after the user grants Android's consent prompt.

## Metrics and terminology

The overlay label `OBR./MIN` means the sum of detected damage events in a rolling 60-second window. This is **damage per minute (DPM)**, not the conventional DPS (damage per second).

XP starts at zero when the measurement service starts and increases only when the OCR recognizes a full numeric `EP` message. Missed or misread messages will make the total inaccurate.

## Known limitations / next engineering tasks

- Improve numeric detection and reject unrelated numbers from the interface.
- Validate green damage-number detection across different game areas, effects, and character levels.
- Validate full `EP` message recognition when it overlaps damage numbers.
- Improve duplicate suppression for events that persist across multiple frames.
- Test performance and memory use on a physical Android device.
- Handle MediaProjection lifecycle and newer Android foreground-service requirements robustly.
- Add automated tests for parsing, rolling-window totals, and duplicate filtering.
- Add a Gradle Wrapper and CI build after verifying a clean local build.

## Privacy

The app captures the screen only after explicit Android consent and processes frames on-device using ML Kit. This prototype does not intentionally upload screen images. Review the code and Android permissions before installing any build. Avoid recording or sharing screens containing private messages or account details.

## Contributing

Bug reports and improvement ideas are welcome. Please include your Android version, device model, reproduction steps, and logs where possible. Do not upload private account data or screenshots containing personal information. See [CONTRIBUTING.md](CONTRIBUTING.md).

## Project name and affiliation

TibiaME Assist is an independent community project. It is not an official TibiaME product and is not affiliated with or endorsed by the game publisher. TibiaME and related names/assets belong to their respective owners.

## License

No open-source license has been selected yet. Until a license is added, assume that the source is shared for review only and that ordinary copyright restrictions apply. Choose and add a license before inviting reuse or redistribution.
