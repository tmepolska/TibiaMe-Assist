# Security and privacy

This project is an experimental Android screen-overlay and screen-capture tool.

- Do not submit passwords, signing keys, access tokens, or private account data in issues.
- Before sharing a log or screenshot, remove personal messages and identifying information.
- Report suspected security or privacy issues privately to the repository maintainer rather than publishing exploit details in a public issue. Add the maintainer's contact here once a project contact address is established.

Screen capture requires explicit Android user consent. Review permission and capture behavior before installing builds from untrusted sources.
