# Contributing

Thanks for helping improve TibiaME Assist. The project is experimental, so reproducible bug reports are especially useful.

## Before opening an issue

- Check existing issues for duplicates.
- Use a recent source checkout and note the commit or archive version.
- State your phone model and Android version.
- Describe the exact steps, expected result, and actual result.
- Include relevant logs or a minimal reproduction where possible.
- Remove personal information, account identifiers, private chats, and credentials from screenshots/logs.

## Code changes

- Keep changes focused and explain why they are needed.
- Prefer small functions for OCR parsing, event de-duplication, and rolling-window calculations.
- Do not claim OCR accuracy without recording the test conditions and observed false positives/false negatives.
- Do not commit APK signing keys, credentials, local SDK paths, or private gameplay captures.
- Test a clean Android Studio/Gradle sync and build before submitting, where possible.

## Pull requests

Include a short summary, testing performed, device/Android version if relevant, and known limitations. If a change affects screen capture or overlay permissions, explain the user-visible behavior and privacy implications.
