package pl.tibiame.assist

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val captureRequest = 4701
    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(0xFF101419.toInt())
        }
        val title = TextView(this).apply {
            text = "TibiaME Assist"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "Mała nakładka XP i obrażeń/min.\nOdczyt ekranu wymaga Twojej zgody Androida."
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xFFCAD2DC.toInt())
            setPadding(0, 18, 0, 28)
        }
        status = TextView(this).apply {
            text = "Status: gotowy do uruchomienia"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFF65E6A5.toInt())
            setPadding(0, 8, 0, 18)
        }
        val start = Button(this).apply {
            text = "Uruchom nakładkę i odczyt"
            setOnClickListener { begin() }
        }
        val stop = Button(this).apply {
            text = "Zatrzymaj nakładkę"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureOverlayService::class.java))
                status.text = "Status: zatrzymano"
            }
        }
        root.addView(title)
        root.addView(description)
        root.addView(status)
        root.addView(start)
        root.addView(stop)
        setContentView(root)
    }

    private fun begin() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Najpierw zezwól na wyświetlanie nad innymi aplikacjami."
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            return
        }
        status.text = "Potwierdź udostępnianie ekranu w oknie Androida."
        @Suppress("DEPRECATION")
        startActivityForResult(projectionManager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("MediaProjection consent callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != captureRequest) return
        if (resultCode != RESULT_OK || data == null) {
            status.text = "Nie przyznano zgody na przechwytywanie ekranu."
            return
        }
        val service = Intent(this, CaptureOverlayService::class.java).apply {
            action = CaptureOverlayService.ACTION_START
            putExtra(CaptureOverlayService.EXTRA_RESULT_CODE, resultCode)
            putExtra(CaptureOverlayService.EXTRA_RESULT_DATA, data)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service) else startService(service)
        status.text = "Nakładka uruchomiona. Przejdź do TibiaME i przetestuj odczyt."
    }
}
