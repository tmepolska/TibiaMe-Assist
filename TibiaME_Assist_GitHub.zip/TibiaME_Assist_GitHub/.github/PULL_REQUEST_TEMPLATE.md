## Summary

Describe the change and why it is needed.

## Testing

- [ ] Gradle sync/build attempted
- [ ] Tested on a physical Android device (state model and Android version)
- [ ] OCR false positives/false negatives checked, if relevant
- [ ] No private screenshots, credentials, or signing keys included

## Known limitations

List anything that remains incomplete or unverified.
