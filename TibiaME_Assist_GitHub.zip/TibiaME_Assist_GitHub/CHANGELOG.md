# Changelog

## 0.1.0-alpha — initial source prototype

- Initial Kotlin Android app and floating overlay.
- MediaProjection screen-capture flow with explicit user consent.
- First-pass ML Kit OCR for green damage values and numeric `EP` messages.
- XP session counter and rolling 60-second damage total.
- Pause, reset, and movable overlay controls.

This is an experimental baseline; live-game accuracy and device compatibility are not yet validated.
