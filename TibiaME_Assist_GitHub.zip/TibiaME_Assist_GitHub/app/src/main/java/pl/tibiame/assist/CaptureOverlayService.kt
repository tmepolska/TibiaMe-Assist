package pl.tibiame.assist

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.ArrayDeque
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

class CaptureOverlayService : Service() {
    companion object {
        const val ACTION_START = "pl.tibiame.assist.START"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        private const val CHANNEL_ID = "tibiame_assist_capture"
        private const val NOTIFICATION_ID = 7401
    }

    private lateinit var windowManager: WindowManager
    private lateinit var panel: LinearLayout
    private lateinit var xpText: TextView
    private lateinit var dpmText: TextView
    private lateinit var statusText: TextView
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var reader: ImageReader
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var worker: HandlerThread? = null
    private var workerHandler: Handler? = null
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val processing = AtomicBoolean(false)
    private val damageEvents = ArrayDeque<Pair<Long, Int>>()
    private val recentDamage = ArrayDeque<SeenToken>()
    private val recentXp = ArrayDeque<SeenToken>()
    private var xpTotal = 0L
    private var paused = false
    private var lastFrameAt = 0L
    private var overlayW = 220
    private var overlayH = 112

    private data class SeenToken(val value: Int, val x: Int, val y: Int, val time: Long)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START) {
            createNotificationChannel()
            startForeground(NOTIFICATION_ID, buildNotification())
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
            @Suppress("DEPRECATION")
            val data = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
            if (data != null) startCapture(resultCode, data)
        }
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        if (projection != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createOverlay()
        worker = HandlerThread("TibiaMEAssistOCR").apply { start() }
        workerHandler = Handler(worker!!.looper)
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, workerHandler)
        virtualDisplay = projection?.createVirtualDisplay(
            "TibiaMEAssistCapture", width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, workerHandler
        )
        reader.setOnImageAvailableListener({ source ->
            val now = SystemClock.elapsedRealtime()
            if (now - lastFrameAt < 350 || paused || !processing.compareAndSet(false, true)) {
                source.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            lastFrameAt = now
            val image = source.acquireLatestImage()
            if (image == null) { processing.set(false); return@setOnImageAvailableListener }
            val bitmap = try { imageToBitmap(image) } catch (_: Exception) { null } finally { image.close() }
            if (bitmap == null) { processing.set(false); return@setOnImageAvailableListener }
            val input = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(input)
                .addOnSuccessListener { result -> processRecognizedText(result, bitmap) }
                .addOnFailureListener { statusText.post { statusText.text = "OCR: błąd" } }
                .addOnCompleteListener { bitmap.recycle(); processing.set(false) }
        }, workerHandler)
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        buffer.rewind()
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val paddedWidth = rowStride / pixelStride
        val full = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(full, 0, 0, image.width, image.height)
        full.recycle()
        return cropped
    }

    private fun processRecognizedText(result: Text, bitmap: Bitmap) {
        val now = SystemClock.elapsedRealtime()
        val overlayRect = Rect(params.x, params.y, params.x + panel.width.coerceAtLeast(overlayW), params.y + panel.height.coerceAtLeast(overlayH))
        val xpRegex = Regex("(?i)(\\d{1,4})\\s*EP")
        var foundDamage = 0
        var foundXp = false
        for (block in result.textBlocks) {
            for (line in block.lines) {
                val lineBox = line.boundingBox ?: continue
                if (!Rect.intersects(lineBox, Rect(0, 0, bitmap.width, bitmap.height))) continue
                // EXP is a white floating message. Count only a full numeric EP token, not isolated digits.
                val xpMatch = xpRegex.find(line.text)
                if (xpMatch != null && !Rect.intersects(lineBox, overlayRect)) {
                    val value = xpMatch.groupValues[1].toIntOrNull()
                    val cx = lineBox.centerX(); val cy = lineBox.centerY()
                    if (value != null && value in 1..9999 && !isRecent(recentXp, value, cx, cy, now, 1500)) {
                        recentXp.addLast(SeenToken(value, cx, cy, now))
                        xpTotal += value
                        foundXp = true
                    }
                }
                // Damage is accepted only when ML Kit sees a numeric element and its pixels are green.
                for (element in line.elements) {
                    val token = element.text.trim()
                    if (!token.matches(Regex("\\d{1,4}"))) continue
                    val box = element.boundingBox ?: continue
                    if (box.width() < 18 || box.height() < 10 || Rect.intersects(box, overlayRect)) continue
                    if (box.left < bitmap.width * 0.18 || box.right > bitmap.width * 0.88 || box.top < bitmap.height * 0.15 || box.bottom > bitmap.height * 0.62) continue
                    val value = token.toIntOrNull() ?: continue
                    if (value !in 1..9999) continue
                    if (greenPixelRatio(bitmap, box) < 0.18) continue
                    val cx = box.centerX(); val cy = box.centerY()
                    if (!isRecent(recentDamage, value, cx, cy, now, 850)) {
                        recentDamage.addLast(SeenToken(value, cx, cy, now))
                        synchronized(damageEvents) { damageEvents.addLast(now to value) }
                        foundDamage++
                    }
                }
            }
        }
        updateCounters()
        statusText.post {
            statusText.text = when {
                foundDamage > 0 && foundXp -> "Odczyt: +DMG i +XP"
                foundDamage > 0 -> "Odczyt: +$foundDamage trafienie"
                foundXp -> "Odczyt: EXP dodany"
                else -> "OCR aktywny · analiza ekranu"
            }
        }
    }

    private fun greenPixelRatio(bitmap: Bitmap, box: Rect): Double {
        val left = box.left.coerceIn(0, bitmap.width - 1)
        val top = box.top.coerceIn(0, bitmap.height - 1)
        val right = box.right.coerceIn(left + 1, bitmap.width)
        val bottom = box.bottom.coerceIn(top + 1, bitmap.height)
        var total = 0; var green = 0
        val stepX = (right - left) / 12 + 1
        val stepY = (bottom - top) / 8 + 1
        var y = top
        while (y < bottom) {
            var x = left
            while (x < right) {
                val pixel = bitmap.getPixel(x, y)
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                if (g > 105 && g > r * 1.22 && g > b * 1.12) green++
                total++
                x += stepX
            }
            y += stepY
        }
        return if (total == 0) 0.0 else green.toDouble() / total
    }

    private fun isRecent(queue: ArrayDeque<SeenToken>, value: Int, x: Int, y: Int, now: Long, window: Long): Boolean {
        while (queue.isNotEmpty() && now - queue.first.time > window) queue.removeFirst()
        return queue.any { it.value == value && abs(it.x - x) < 85 && abs(it.y - y) < 75 && now - it.time <= window }
    }

    private fun createOverlay() {
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 7, 10, 8)
            setBackgroundColor(0xDD101419.toInt())
        }
        val handle = TextView(this).apply {
            text = "⠿ TibiaME Assist  ·  −"
            textSize = 12f
            setTextColor(0xFFB9C4D0.toInt())
            setPadding(2, 0, 2, 4)
        }
        xpText = TextView(this).apply { text = "XP SESJI  +0"; textSize = 15f; setTextColor(0xFF65E6A5.toInt()) }
        dpmText = TextView(this).apply { text = "OBR./MIN  0"; textSize = 15f; setTextColor(0xFF62C9FF.toInt()) }
        statusText = TextView(this).apply { text = "OCR: start"; textSize = 10f; setTextColor(0xFFB9C4D0.toInt()) }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val pause = TextView(this).apply {
            text = "PAUZA"; textSize = 10f; setTextColor(0xFFFFFFFF.toInt()); setPadding(4, 4, 12, 0)
            setOnClickListener { paused = !paused; text = if (paused) "WZNÓW" else "PAUZA" }
        }
        val reset = TextView(this).apply {
            text = "RESET"; textSize = 10f; setTextColor(0xFFFFFFFF.toInt()); setPadding(8, 4, 4, 0)
            setOnClickListener { synchronized(damageEvents) { damageEvents.clear() }; xpTotal = 0; recentDamage.clear(); recentXp.clear(); updateCounters() }
        }
        controls.addView(pause); controls.addView(reset)
        panel.addView(handle); panel.addView(xpText); panel.addView(dpmText); panel.addView(statusText); panel.addView(controls)
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 220 }
        windowManager.addView(panel, params)
        var startX = 0; var startY = 0; var downX = 0f; var downY = 0f
        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; downX = event.rawX; downY = event.rawY; true }
                MotionEvent.ACTION_MOVE -> { params.x = startX + (event.rawX - downX).toInt(); params.y = startY + (event.rawY - downY).toInt(); windowManager.updateViewLayout(panel, params); true }
                else -> true
            }
        }
    }

    private fun updateCounters() {
        val now = SystemClock.elapsedRealtime()
        synchronized(damageEvents) {
            while (damageEvents.isNotEmpty() && now - damageEvents.first.first > 60_000) damageEvents.removeFirst()
            val dpm = damageEvents.sumOf { it.second }
            xpText.post { xpText.text = "XP SESJI  +$xpTotal" }
            dpmText.post { dpmText.text = "OBR./MIN  $dpm" }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "TibiaME Assist", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("TibiaME Assist działa")
            .setContentText("Nakładka i analiza ekranu są aktywne")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true).build()
    }

    override fun onDestroy() {
        try { if (::windowManager.isInitialized && ::panel.isInitialized) windowManager.removeView(panel) } catch (_: Exception) {}
        virtualDisplay?.release(); virtualDisplay = null
        projection?.stop(); projection = null
        if (::reader.isInitialized) reader.close()
        worker?.quitSafely(); worker = null
        try { recognizer.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
