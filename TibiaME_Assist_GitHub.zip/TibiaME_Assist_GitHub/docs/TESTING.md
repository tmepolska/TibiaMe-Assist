# Manual test checklist

Use a test character or gameplay session where it is safe to stop and inspect the overlay.

## Startup and permissions

- [ ] App opens without crashing.
- [ ] Overlay permission flow returns to the app correctly.
- [ ] Screen-capture consent is shown and capture starts only after approval.
- [ ] Persistent notification appears while the capture service is active.
- [ ] Stopping the service removes the overlay and stops capture.

## Overlay

- [ ] Panel remains above TibiaME.
- [ ] Panel can be dragged without blocking all game controls.
- [ ] Pause stops new counting.
- [ ] Reset clears XP and the rolling damage window.
- [ ] Panel can be stopped and restarted without duplicate services.

## OCR accuracy

Record each visible event and the app result. Count a result as correct only if it matches the visible value and is added exactly once.

- [ ] Small green damage numbers.
- [ ] Three- and four-digit green damage numbers.
- [ ] Red damage received by the player is not counted as outgoing damage.
- [ ] White numeric `EP` messages are read as a whole value.
- [ ] EXP text overlapping damage numbers.
- [ ] Multiple monsters and moving combat text.
- [ ] Repeated frames do not count the same floating number more than once.
- [ ] No unrelated interface numbers are counted.

## Performance

- [ ] No sustained excessive battery drain or overheating during a 10-minute test.
- [ ] Game remains responsive.
- [ ] Capture stops when Android revokes the MediaProjection session.

Document device model, Android version, sample duration, true visible events, correct detections, missed detections, and false positives. Do not report an accuracy percentage without these counts.
